package com.example.android.songs;

class Music {
    /**
     * Song name
     */
    private String songName;

    /**
     * artist name of the song
     */
    private String artistName;

    /**
     * @param songName name of song
     * @param artistName name of artist
     */
    Music(String songName, String artistName) {
        this.songName = songName;
        this.artistName = artistName;
    }
    String getSongName() {
        return songName;
    }

    /**
     *
     * @return artist name of the song
     */
    String getArtistName() {
        return artistName;
    }
}
