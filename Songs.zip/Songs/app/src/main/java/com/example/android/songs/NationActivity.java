package com.example.android.songs;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;

public class NationActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nation);

        // Create a list of songs
        final ArrayList<Music> songsList = new ArrayList<>();
        songsList.add(new Music("Rapture", "Koffee ft. Govana"));
        songsList.add(new Music("Don't Start Now", "Dua Lipa"));
        songsList.add(new Music("All To Myself", "Baby Rose"));
        songsList.add(new Music("Dumebi", "Rema"));
        songsList.add(new Music("Nina", "Rapsody"));
        songsList.add(new Music("All Mirrors", "Angel Olsen"));
        songsList.add(new Music("Senorita", "Shawn Mendes and Camila Cabello"));
        songsList.add(new Music("Anybody", "Burna Boy"));
        songsList.add(new Music("My Type", "Saweetie"));
        songsList.add(new Music("Morning", "Teyana Taylor ft. Kehlani"));

        MusicAdapter songAdapter = new MusicAdapter(this, songsList);

        ListView listView = findViewById(R.id.listview);
        listView.setAdapter(songAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(NationActivity.this, InfoActivity.class);
                intent.putExtra("song_name", songsList.get(position).getSongName());
                intent.putExtra("artist_name", songsList.get(position).getArtistName());
                startActivity(intent);
            }
        });
    }
}
